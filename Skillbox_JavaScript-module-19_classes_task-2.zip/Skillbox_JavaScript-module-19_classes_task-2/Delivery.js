export class Delivery {
  constructor(name, address, distance) {
    this._name = name;
    this._address = address;
    this._distance = distance;
  }

  get name() {
    return this._name;
  }

  set name(newName) {
    this._name = newName;
  }

  get address() {
    return this._address;
  }

  set address(newAddress) {
    this._address = newAddress;
  }

  get distance() {
    return this._distance;
  }

  set distance(newDistance) {
    this._distance = newDistance;
  }

   static translateStatus(status) {
    switch (status) {
      case "delivery":
        return "Доставляется";
      case "delivered":
        return "Доставлен";
      case "canceled":
        return "Отменён";
      default:
        return status;
    }
  }

}

export class EditDelivery extends Delivery {
  constructor(name, address, distance, status = "delivery") {
    super(name, address, distance);
    this._status = status;
  }

  get status() {
    return this._status;
  }

  set status(newStatus) {
    this._status = newStatus;
  }

    static translateStatus(status) {
    switch (status) {
      case "delivery":
        return "Доставляется";
      case "delivered":
        return "Доставлен";
      case "canceled":
        return "Отменён";
      default:
        return status;
    }
  }


  createCardElement() {
    const card = document.createElement("div");
    card.className = `delivery-card ${this._status}`;

// <p><strong>Статус:</strong> ${this.status}</p> эта строка заменена на нижнюю для перевода
// <p><strong>Статус:</strong> ${EditDelivery.translateStatus(this.status)}</p>
    card.innerHTML = `
      <div class = "wrapper"><p class = "name">Имя:</p>
         <button class="edit-btn">Изменить</button>
      </div>
      <span>${this.name}</span>
      <p>Адрес:</p>
      <span>${this.address}</span>
      <p>Расстояние:</p>
      <span>${this.distance} км</span>
      <p><strong>Статус:</strong> ${EditDelivery.translateStatus(this.status)}</p>
    `;

    const editBtn = card.querySelector(".edit-btn");
    editBtn.addEventListener("click", () => {
      this.showEditForm(card);
    });

    return card;
  }

  showEditForm(container) {
    const overlay = document.createElement("div");
    overlay.className = "overlay";

    const modal = document.createElement("div");
    modal.className = "modal";

    const closeButton = document.createElement("button");
    closeButton.className = "close-btn";
    closeButton.innerHTML = "&times;";
    closeButton.addEventListener("click", () => {
      document.body.removeChild(overlay);
      document.body.removeChild(modal);
    });

    const form = document.createElement("form");
    form.className = "edit-form";
    form.innerHTML = `
      <h3 class = "title-form">Изменить</h3>
        <input type="text" name="name" placeholder="Имя" value="${this.name}" />

        <input type="text" name="address" placeholder="Адрес" value="${this.address}" />


        <input type="number" name="distance" placeholder="Расстояние" value="${this.distance}" />

        <select name="status">
          <option value="delivery" ${this.status === "delivery" ? "selected" : ""}>Доставляется</option>
          <option value="delivered" ${this.status === "delivered" ? "selected" : ""}>Доставлен</option>
          <option value="canceled" ${this.status === "canceled" ? "selected" : ""}>Отменён</option>
        </select>
      <button type="submit">Сохранить</button>
    `;

    form.addEventListener("submit", (e) => {
      e.preventDefault();
      this.name = form.name.value;
      this.address = form.address.value;
      this.distance = parseFloat(form.distance.value);
      this.status = form.status.value;

      const updatedCard = this.createCardElement();
      container.replaceWith(updatedCard);

      document.body.removeChild(overlay);
      document.body.removeChild(modal);
    });

    modal.appendChild(closeButton);
    modal.appendChild(form);
    document.body.appendChild(overlay);
    document.body.appendChild(modal);
  }

  static getTotalDistance(deliveries) {
    return deliveries
      .filter(delivery => delivery.status !== "canceled")
      .reduce((sum, delivery) => sum + delivery.distance, 0);
  }

}
